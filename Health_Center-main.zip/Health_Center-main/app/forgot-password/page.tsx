"use client";

import React from "react";
import { supabase } from "@/lib/supabaseClient";

export default function ForgotPasswordPage() {
  const [email, setEmail] = React.useState("");
  const [message, setMessage] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);

  async function handleReset(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setLoading(true);

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/reset-password`,
    });

    if (error) setError(error.message);
    else setMessage("If this email exists, a reset link has been sent!");

    setLoading(false);
  }

  return (
    <main
      className="min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat relative"
      style={{ backgroundImage: "url('/background.webp')" }}
    >
      <div className="absolute inset-0 bg-black/20 backdrop-blur-[2px]" />
      <div className="relative z-10 w-full max-w-md bg-white/60 backdrop-blur-md shadow-2xl border border-white/30 rounded-2xl p-8">
        <h1 className="text-2xl font-semibold text-center text-slate-800">Forgot Password</h1>
        <p className="mt-2 text-center text-sm text-slate-600">
          Enter your email address to reset your password.
        </p>

        <form onSubmit={handleReset} className="mt-6 space-y-4">
          <div>
            <label htmlFor="email" className="text-sm font-medium text-slate-700">
              Email
            </label>
            <input
              id="email"
              type="email"
              required
              className="mt-2 w-full rounded-md border border-slate-200 bg-white/70 p-2 text-sm shadow-sm focus:border-[#A8CDD2] focus:ring-2 focus:ring-[#A8CDD2]/40 outline-none transition"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-md bg-[#A8CDD2] text-white py-2 font-medium text-sm shadow hover:opacity-90 hover:shadow-lg transition disabled:opacity-60"
          >
            {loading ? "Sending..." : "Send Reset Link"}
          </button>

          {error && (
            <div className="mt-3 rounded-md border border-red-200 bg-red-50 text-red-700 p-3 text-sm">{error}</div>
          )}
          {message && (
            <div className="mt-3 rounded-md border border-green-200 bg-green-50 text-green-700 p-3 text-sm">{message}</div>
          )}
        </form>
      </div>
    </main>
  );
}
