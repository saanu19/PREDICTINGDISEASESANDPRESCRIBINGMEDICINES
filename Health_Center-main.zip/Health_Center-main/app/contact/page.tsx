export default function ContactPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-12 min-h-[calc(100vh-200px)] flex flex-col items-center justify-start">
      <h1 className="text-3xl font-semibold text-center mb-8">Contact Us</h1>

      <div className="max-w-3xl text-muted-foreground leading-relaxed space-y-4 text-justify">
        <p>
          {
            "Have questions or need assistance? We're here to help! Whether it's a technical issue, feedback, or general inquiry — feel free to reach out to us anytime."
          }
        </p>

        <h2 className="text-xl font-semibold mt-6">Customer Support</h2>
        <p>
          {
            "Our dedicated support team is always available to assist you with your queries. We take pride in offering fast, friendly, and reliable support to ensure a smooth experience on our platform."
          }
        </p>

        <h2 className="text-xl font-semibold mt-6">Get in Touch</h2>
        <p>
          {
            "You can contact us directly via email or phone. We value your feedback and are committed to providing timely responses."
          }
        </p>

        <ul className="list-none space-y-1">
          <li>
            <strong>Email:</strong>{" "}
            <a
              href="mailto:junaidmehsuud035@gmail.com"
              className="text-blue-600 hover:underline"
            >
              22cs-sahana4628@yit.edu.in
            </a>
          </li>
          <li>
            <strong>Phone:</strong>{" "}
            <a href="tel:+923477155035" className="text-blue-600 hover:underline">
+91 87922 61417            </a>
          </li>
        </ul>

        <h2 className="text-xl font-semibold mt-6">Location</h2>
        <p>{"Yenepoya Institute of Technology, Moodbidri"}</p>

        <p className="italic text-center text-sm mt-8">
          {
            "We value your time and feedback. Thank you for choosing Health Center — your trusted digital health companion."
          }
        </p>
      </div>
    </main>
  );
}
