import { NextResponse } from "next/server"
import fs from "fs/promises"
import path from "path"
import Papa from "papaparse"
import { distance as levenshtein } from "fastest-levenshtein"

type Row = Record<string, string>
type Disease = string

// Cache loaded datasets across requests
let loaded = false
let symptomMatrix: { disease: Disease; symptoms: Set<string> }[] = []
let knownSymptoms: string[] = []
const descMap = new Map<Disease, string>()
const precautionsMap = new Map<Disease, string[]>()
const medsMap = new Map<Disease, string[]>()
const dietMap = new Map<Disease, string[]>()
const workoutMap = new Map<Disease, string[]>()
let canonicalSymptoms: string[] = []
const aliasToCanonical = new Map<string, string>()

function norm(s: string) {
  return s
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "")
}

// Try to parse CSV text into rows
function parseCsv(text: string): Row[] {
  const parsed = Papa.parse<Row>(text, { header: true, skipEmptyLines: true })
  if (parsed.errors?.length) {
    // If there are parser errors, still return whatever data is available
    // console.log('[v0] CSV parse errors:', parsed.errors)
  }
  return (parsed.data || []).map((r) => {
    const clean: Row = {}
    Object.keys(r || {}).forEach((k) => {
      clean[k.trim()] = (r as any)[k]
    })
    return clean
  })
}

async function loadDatasets() {
  if (loaded) return

  const base = path.join(process.cwd(), "public", "datasets")

  // Read all datasets
  const [symText, descText, precText, medsText, dietsText, workoutText, severText] = await Promise.all([
    fs.readFile(path.join(base, "symtoms_df.csv"), "utf8"),
    fs.readFile(path.join(base, "description.csv"), "utf8"),
    fs.readFile(path.join(base, "precautions_df.csv"), "utf8"),
    fs.readFile(path.join(base, "medications.csv"), "utf8"),
    fs.readFile(path.join(base, "diets.csv"), "utf8"),
    fs.readFile(path.join(base, "workout_df.csv"), "utf8"),
    fs.readFile(path.join(base, "Symptom-severity.csv"), "utf8"),
  ])

  const symRows = parseCsv(symText)
  const descRows = parseCsv(descText)
  const precRows = parseCsv(precText)
  const medsRows = parseCsv(medsText)
  const dietRows = parseCsv(dietsText)
  const wrkRows = parseCsv(workoutText)
  const sevRows = parseCsv(severText)

  // Build description map
  for (const r of descRows) {
    const d = (r["Disease"] || r["disease"] || "").trim()
    const description = (r["Description"] || r["description"] || "").trim()
    if (d) descMap.set(d, description)
  }

  // Build precautions map (Precaution_1..4)
  for (const r of precRows) {
    const d = (r["Disease"] || r["disease"] || "").trim()
    if (!d) continue
    const vals = ["Precaution_1", "Precaution_2", "Precaution_3", "Precaution_4"]
      .map((k) => (r[k] || "").toString().trim())
      .filter(Boolean)
    precautionsMap.set(d, vals)
  }

  // Build medications (may be multiple rows per disease)
  for (const r of medsRows) {
    const d = (r["Disease"] || r["disease"] || "").trim()
    const m = (r["Medication"] || r["medication"] || "").toString().trim()
    if (!d || !m) continue
    if (!medsMap.has(d)) medsMap.set(d, [])
    const arr = medsMap.get(d)!
    if (!arr.includes(m)) arr.push(m)
  }

  // Build diet (may be multiple rows per disease)
  for (const r of dietRows) {
    const d = (r["Disease"] || r["disease"] || "").trim()
    const di = (r["Diet"] || r["diet"] || "").toString().trim()
    if (!d || !di) continue
    if (!dietMap.has(d)) dietMap.set(d, [])
    const arr = dietMap.get(d)!
    if (!arr.includes(di)) arr.push(di)
  }

  // Build workout (note: original used lowercase 'disease' column)
  for (const r of wrkRows) {
    const d = (r["disease"] || r["Disease"] || "").trim()
    const w = (r["workout"] || "").toString().trim()
    if (!d || !w) continue
    if (!workoutMap.has(d)) workoutMap.set(d, [])
    const arr = workoutMap.get(d)!
    if (!arr.includes(w)) arr.push(w)
  }

  // Build symptom matrix (assumes one-hot format: disease/prognosis + many symptom columns with 0/1)
  // Try to detect label column
  const firstSymRow = symRows[0] || {}
  const keys = Object.keys(firstSymRow).filter((k) => k !== "")
  const hasNameColumns = keys.some((k) => /^Symptom_/i.test(k))

  const diseaseMap = new Map<Disease, Set<string>>()

  if (hasNameColumns) {
    // Format A: Disease + Symptom_1.. (strings)
    const labelKey = keys.find((k) => ["Disease", "disease", "prognosis"].includes(k)) || "Disease"

    // Collect all columns that look like Symptom_*
    const symptomNameCols = keys.filter((k) => /^Symptom_/i.test(k))

    // Build disease -> set(symptoms) using the symptom names in cells
    for (const r of symRows) {
      const disease = (r[labelKey] || "").toString().trim()
      if (!disease) continue
      if (!diseaseMap.has(disease)) diseaseMap.set(disease, new Set<string>())
      const set = diseaseMap.get(disease)!
      for (const col of symptomNameCols) {
        const val = (r[col] || "").toString().trim()
        if (!val) continue
        set.add(norm(val))
      }
    }

    // Canonical symptoms are the union of all normalized symptom names found
    const unionSet = new Set<string>()
    for (const set of diseaseMap.values()) {
      for (const s of set) unionSet.add(s)
    }
    canonicalSymptoms = Array.from(unionSet)
  } else {
    // Format B: One-hot
    const labelKey = keys.find((k) => ["Disease", "disease", "prognosis"].includes(k)) || "Disease"

    const symptomCols = keys.filter((k) => k !== labelKey)
    canonicalSymptoms = symptomCols.map((c) => norm(c))

    for (const r of symRows) {
      const disease = (r[labelKey] || "").toString().trim()
      if (!disease) continue
      if (!diseaseMap.has(disease)) diseaseMap.set(disease, new Set<string>())

      const set = diseaseMap.get(disease)!
      for (const col of symptomCols) {
        const raw = (r[col] ?? "").toString().trim()
        const present = raw === "1" || raw.toLowerCase?.() === "true" || raw.toLowerCase?.() === "yes"
        if (present) set.add(norm(col))
      }
    }
  }

  // Replace previous symptomMatrix build with our unified diseaseMap
  symptomMatrix = Array.from(diseaseMap.entries()).map(([d, set]) => ({
    disease: d,
    symptoms: set,
  }))

  // Build alias mapping from Symptom-severity.csv
  const severitySymptoms = new Set<string>()
  for (const r of sevRows) {
    const s = (r["Symptom"] || r["symptom"] || r["SYMPTOM"] || "").toString().trim()
    if (!s) continue
    severitySymptoms.add(norm(s))
  }

  // Map each severity symptom to the closest canonical one so users can input either form
  aliasToCanonical.clear()
  for (const alias of severitySymptoms) {
    if (canonicalSymptoms.includes(alias)) {
      aliasToCanonical.set(alias, alias)
      continue
    }
    let best: string | undefined
    let bestScore = 0
    for (const can of canonicalSymptoms) {
      const dist = levenshtein(alias, can)
      const maxLen = Math.max(alias.length, can.length) || 1
      const score = 1 - dist / maxLen
      if (score > bestScore) {
        bestScore = score
        best = can
      }
    }
    if (best && bestScore >= 0.7) {
      aliasToCanonical.set(alias, best)
    }
  }

  // Known symptoms now includes both canonical and aliases
  knownSymptoms = Array.from(new Set<string>([...canonicalSymptoms, ...severitySymptoms]))

  loaded = true
}

function fuzzyMatchSymptom(input: string): { matched?: string; confidence: number } {
  const normalized = norm(input)
  if (!normalized) return { confidence: 0 }

  // If input matches an alias, map to canonical
  if (aliasToCanonical.has(normalized)) {
    return { matched: aliasToCanonical.get(normalized)!, confidence: 1 }
  }

  // Exact match against canonical
  if (canonicalSymptoms.includes(normalized)) {
    return { matched: normalized, confidence: 1 }
  }

  // Fuzzy: consider both aliases and canonical, but resolve to canonical
  let bestKey: string | undefined
  let bestScore = 0
  for (const ks of knownSymptoms) {
    const dist = levenshtein(normalized, ks)
    const maxLen = Math.max(normalized.length, ks.length) || 1
    const score = 1 - dist / maxLen
    if (score > bestScore) {
      bestScore = score
      bestKey = ks
    }
  }
  if (bestKey && bestScore >= 0.7) {
    // Resolve alias to canonical if needed
    const canonical = aliasToCanonical.get(bestKey) || bestKey
    return { matched: canonical, confidence: bestScore }
  }
  return { confidence: bestScore }
}

export async function POST(req: Request) {
  try {
    await loadDatasets()
  } catch (e: any) {
    return NextResponse.json(
      {
        error:
          "Failed to load datasets. Ensure your CSV files are present under /public/datasets with the expected filenames: symtoms_df.csv, description.csv, precautions_df.csv, medications.csv, diets.csv, workout_df.csv, Symptom-severity.csv.",
      },
      { status: 500 },
    )
  }

  let body: any = {}
  try {
    body = await req.json()
  } catch {
    /* ignore */
  }

  const symptomsInput = (body?.symptoms || "").toString()
  if (!symptomsInput.trim()) {
    return NextResponse.json({ error: "Please provide symptoms (comma-separated)." }, { status: 400 })
  }

  // Parse user symptoms
  const userInputs = symptomsInput
    .split(",")
    .map((s: string) => s.trim())
    .filter(Boolean)

  const matchedSet = new Set<string>()
  const autoMatched: Record<string, string> = {}
  const ignored: string[] = []

  for (const raw of userInputs) {
    const { matched } = fuzzyMatchSymptom(raw)
    if (matched) {
      matchedSet.add(matched)
      if (norm(raw) !== matched) autoMatched[raw] = matched
    } else {
      ignored.push(raw)
    }
  }

  if (matchedSet.size === 0) {
    const examples = canonicalSymptoms.slice(0, 5).join(", ")
    return NextResponse.json(
      {
        message: "No recognized symptoms found. Please check spelling or use common symptom names from the dataset.",
        examples: examples ? `Examples: ${examples}` : undefined,
      },
      { status: 400 },
    )
  }

  // Score diseases by Jaccard similarity
  let bestDisease: Disease | undefined
  let bestScore = -1
  for (const row of symptomMatrix) {
    const inter = new Set([...matchedSet].filter((s) => row.symptoms.has(s)))
    const union = new Set([...matchedSet, ...row.symptoms])
    const jaccard = union.size > 0 ? inter.size / union.size : 0
    if (jaccard > bestScore) {
      bestScore = jaccard
      bestDisease = row.disease
    }
  }

  if (!bestDisease) {
    return NextResponse.json({
      message: "Unable to determine a likely disease from the provided symptoms.",
      autoMatched: Object.keys(autoMatched).length ? autoMatched : undefined,
    })
  }

  const description = descMap.get(bestDisease) || ""
  const precautions = precautionsMap.get(bestDisease) || []
  const medications = medsMap.get(bestDisease) || []
  const diet = dietMap.get(bestDisease) || []
  const workout = workoutMap.get(bestDisease) || []

  const parts: string[] = []
  if (Object.keys(autoMatched).length) {
    const mapping = Object.entries(autoMatched)
      .map(([r, m]) => `'${r}'→'${m}'`)
      .join(", ")
    parts.push(`Auto-matched: ${mapping}.`)
  }

  return NextResponse.json({
    predictedDisease: bestDisease,
    description,
    precautions,
    medications,
    diet,
    workout,
    message: parts.length ? parts.join(" ") : undefined,
    autoMatched: Object.keys(autoMatched).length ? autoMatched : undefined,
  })
}