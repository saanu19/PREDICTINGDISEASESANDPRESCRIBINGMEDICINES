export default function AboutPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-12 min-h-[calc(100vh-200px)] flex flex-col items-center justify-start">
      <h1 className="text-3xl font-semibold text-center mb-8">About Health Center</h1>

      <div className="max-w-3xl text-muted-foreground leading-relaxed space-y-4 text-justify">
        <p>
          {
            "Health Center is an innovative healthcare platform that uses advanced Machine Learning techniques to predict diseases and suggest possible medicines based on user-reported symptoms. It aims to provide accessible, intelligent, and educational health insights to everyone."
          }
        </p>

        <h2 className="text-xl font-semibold mt-6">Our Vision</h2>
        <p>
          {
            "We envision a future where technology empowers individuals to take proactive control of their health. Our platform bridges the gap between complex medical data and everyday users by offering reliable and easy-to-understand information."
          }
        </p>

        <h2 className="text-xl font-semibold mt-6">Our Mission</h2>
        <p>
          {
            "Our mission is to leverage Artificial Intelligence and data science to make healthcare guidance more accessible. By analyzing symptoms through trained ML models, we provide users with potential disease predictions and general medical guidance for awareness."
          }
        </p>

        <h2 className="text-xl font-semibold mt-6">How It Works</h2>
        <p>
          {
            "The system collects user symptoms and processes them using machine learning models such as Decision Trees, Random Forests, and Support Vector Machines. It then predicts the most probable disease and displays relevant information, including common medications, precautions, and care tips."
          }
        </p>

        <h2 className="text-xl font-semibold mt-6">Technology Stack</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>{"Frontend: Next.js, Tailwind CSS, and TypeScript"}</li>
          <li>{"Backend: Next.js API Routes (Serverless Functions)"}</li>
          <li>{"Machine Learning: Scikit-learn, Pandas, NumPy for training and prediction"}</li>
          <li>{"Database: Supabase for signup/signin logic"}</li>
        </ul>

        <h2 className="text-xl font-semibold mt-6">Our Commitment</h2>
        <p>
          {
            "We are committed to maintaining accuracy, privacy, and transparency in every aspect of our system. Our team ensures that all predictions are based on verified medical data and tested algorithms."
          }
        </p>
      </div>
    </main>
  );
}
