export default function DeveloperPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-12 min-h-[calc(100vh-200px)] flex flex-col items-center justify-start">
      <h1 className="text-3xl font-semibold text-center mb-8">Developer Team</h1>

      <div className="max-w-3xl text-muted-foreground leading-relaxed space-y-4 text-justify">
        <p>
          {
            "The Health Center project was developed by a passionate team of students who combined their skills in web development, data science, and machine learning to build an intelligent health prediction system."
          }
        </p>

        <h2 className="text-xl font-semibold mt-6">Team Members</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>{"Mohammed Ayaan Saheb - 4DM22CS061"}</li>
          <li>{"Ramya L - 4DM22CS081"}</li>
          <li>{"Sahana C P - 4DM22CS089"}</li>
          <li>{"Spoorthi - 4DM22CS114"}</li>
        </ul>

        <h2 className="text-xl font-semibold mt-6">Development Roles</h2>
        <ul className="list-disc list-inside space-y-2">
          <li>
            <strong>Frontend:</strong>{" "}
            {"Next.js, Tailwind CSS, and TypeScript — handled by Sahana C P"}
          </li>
          <li>
            <strong>Backend:</strong>{" "}
            {"Next.js API Routes (Serverless Functions) — handled by Ramya L"}
          </li>
          <li>
            <strong>Machine Learning:</strong>{" "}
            {"Scikit-learn, Pandas, NumPy for model training and prediction — handled by Spoorthi"}
          </li>
          <li>
            <strong>Database:</strong>{" "}
            {"Supabase for signin/signup logic — handled by Mohammed Ayaan Saheb"}
          </li>
        </ul>

        <p className="italic text-center text-sm mt-8">
          {"Developed as part of an academic major project under the Department of Computer Science."}
        </p>
      </div>
    </main>
  );
}
