"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

export default function ResetPasswordPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (password !== confirm) {
      setError("Passwords do not match");
      return;
    }
    setLoading(true);

    const { data, error } = await supabase.auth.updateUser({ password });

    if (error) setError(error.message);
    else {
      setMessage("Password updated successfully!");
      setTimeout(() => router.replace("/signin"), 1500);
    }
    setLoading(false);
  }

  return (
    <main
      className="min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat relative"
      style={{ backgroundImage: "url('/background.webp')" }}
    >
      <div className="absolute inset-0 bg-black/20 backdrop-blur-[2px]" />
      <div className="relative z-10 w-full max-w-md bg-white/60 backdrop-blur-md shadow-2xl border border-white/30 rounded-2xl p-8">
        <h1 className="text-2xl font-semibold text-center text-slate-800">Reset Password</h1>
        <p className="mt-2 text-center text-sm text-slate-600">
          Enter your new password below.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label htmlFor="password" className="text-sm font-medium text-slate-700">
              New Password
            </label>
            <input
              id="password"
              type="password"
              required
              className="mt-2 w-full rounded-md border border-slate-200 bg-white/70 p-2 text-sm shadow-sm focus:border-[#A8CDD2] focus:ring-2 focus:ring-[#A8CDD2]/40 outline-none transition"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <div>
            <label htmlFor="confirm" className="text-sm font-medium text-slate-700">
              Confirm Password
            </label>
            <input
              id="confirm"
              type="password"
              required
              className="mt-2 w-full rounded-md border border-slate-200 bg-white/70 p-2 text-sm shadow-sm focus:border-[#A8CDD2] focus:ring-2 focus:ring-[#A8CDD2]/40 outline-none transition"
              placeholder="••••••••"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-md bg-[#A8CDD2] text-white py-2 font-medium text-sm shadow hover:opacity-90 hover:shadow-lg transition disabled:opacity-60"
          >
            {loading ? "Updating..." : "Update Password"}
          </button>

          {error && (
            <div className="mt-3 rounded-md border border-red-200 bg-red-50 text-red-700 p-3 text-sm">{error}</div>
          )}
          {message && (
            <div className="mt-3 rounded-md border border-green-200 bg-green-50 text-green-700 p-3 text-sm">{message}</div>
          )}
        </form>
      </div>
    </main>
  );
}
