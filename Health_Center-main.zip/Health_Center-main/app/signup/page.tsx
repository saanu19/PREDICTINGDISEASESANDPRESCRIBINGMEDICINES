"use client";

import React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

export default function SignUpPage() {
  const router = useRouter();
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [message, setMessage] = React.useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setLoading(true);

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { name } },
    });

    if (error) {
      setError(error.message);
    } else {
      setMessage("Account created! Please check your email to verify your account.");
      setTimeout(() => router.replace("/signin"), 2000);
    }

    setLoading(false);
  }

  return (
    <main
      className="min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat relative"
      style={{ backgroundImage: "url('/background.webp')" }}
    >
      <div className="absolute inset-0 bg-black/20 backdrop-blur-[2px]" />

      <div className="relative z-10 w-full max-w-md bg-white/60 backdrop-blur-md shadow-2xl border border-white/30 rounded-2xl p-8">
        <h1 className="text-2xl font-semibold text-center text-slate-800">Create Account</h1>
        <p className="mt-2 text-center text-sm text-slate-600">
          Join Health Center to get intelligent health insights.
        </p>

        <form onSubmit={onSubmit} className="mt-6 space-y-4" aria-busy={loading}>
          <div>
            <label htmlFor="name" className="text-sm font-medium text-slate-700">
              Name (optional)
            </label>
            <input
              id="name"
              type="text"
              className="mt-2 w-full rounded-md border border-slate-200 bg-white/70 p-2 text-sm shadow-sm focus:border-[#A8CDD2] focus:ring-2 focus:ring-[#A8CDD2]/40 outline-none transition"
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div>
            <label htmlFor="email" className="text-sm font-medium text-slate-700">
              Email
            </label>
            <input
              id="email"
              type="email"
              required
              className="mt-2 w-full rounded-md border border-slate-200 bg-white/70 p-2 text-sm shadow-sm focus:border-[#A8CDD2] focus:ring-2 focus:ring-[#A8CDD2]/40 outline-none transition"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div>
            <label htmlFor="password" className="text-sm font-medium text-slate-700">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              className="mt-2 w-full rounded-md border border-slate-200 bg-white/70 p-2 text-sm shadow-sm focus:border-[#A8CDD2] focus:ring-2 focus:ring-[#A8CDD2]/40 outline-none transition"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="mt-5 w-full rounded-md bg-[#A8CDD2] text-white py-2 font-medium text-sm shadow hover:opacity-90 hover:shadow-lg transition disabled:opacity-60"
          >
            {loading ? "Creating account..." : "Sign up"}
          </button>

          {error && (
            <div className="mt-3 rounded-md border border-red-200 bg-red-50 text-red-700 p-3 text-sm">{error}</div>
          )}
          {message && (
            <div className="mt-3 rounded-md border border-green-200 bg-green-50 text-green-700 p-3 text-sm">{message}</div>
          )}

          <p className="mt-4 text-center text-sm text-slate-700">
            Already have an account?{" "}
            <Link href="/signin" className="font-medium text-[#A8CDD2] hover:underline">
              Sign in
            </Link>
          </p>
        </form>
      </div>
    </main>
  );
}
