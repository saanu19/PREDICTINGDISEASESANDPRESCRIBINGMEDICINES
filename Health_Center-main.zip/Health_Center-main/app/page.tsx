// app/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getUser } from "@/lib/auth"; // your localStorage-based functions
import { Suspense } from "react";
import SymptomForm from "@/components/symptom-form";
import Background from "@/components/background";

export default function HomePage() {
  const router = useRouter();
  const [checked, setChecked] = useState(false); // whether we've read localStorage
  const [user, setUser] = useState(null as null | { email?: string; name?: string });

  useEffect(() => {
    // run on client only
    const u = getUser();
    setUser(u);
    setChecked(true);

    if (!u) {
      // not signed in → send to signin (replace so back button doesn't return here)
      router.replace("/signin");
    }
    // if u exists we stay and render the page
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // while checking for user, avoid showing the protected UI
  if (!checked) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="text-sm text-slate-500">Checking authentication…</span>
      </div>
    );
  }

  // if checked and no user, we've already redirected — return null to avoid flash
  if (!user) return null;

  // Signed-in → show the existing SymptomForm UI
  return (
    <main className="relative min-h-screen text-slate-900 overflow-hidden">
      {/* Background */}
      <Background />

      <div className="relative z-10 mx-auto max-w-5xl px-6 py-20">
        <Suspense>
          <SymptomForm />
        </Suspense>
      </div>
    </main>
  );
}
