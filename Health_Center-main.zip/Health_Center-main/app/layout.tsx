import type { Metadata } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";
import ClientLayout from "../components/ClientLayout";

export const metadata: Metadata = {
  title: "Health Center — Symptom Checker",
  description: "Analyze your symptoms and get personalized health recommendations",
  icons: {
    icon: "/favicon.ico", // 👈 uses your logo from /public/favicon.ico
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body className="min-h-screen flex flex-col antialiased">
        {/* ClientLayout handles Navbar / Background / Footer visibility */}
        <ClientLayout>{children}</ClientLayout>
      </body>
    </html>
  );
}
