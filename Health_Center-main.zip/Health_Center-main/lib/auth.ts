// lib/auth.ts
import { supabase } from "./supabaseClient";

/** Public user type your UI uses */
export type HCUser = {
  id?: string;
  name?: string;
  email: string;
};

const SESSION_KEY = "hc_user"; // current signed-in user

/* ----------------- Helpers ----------------- */
function safeParse<T>(raw: string | null, fallback: T): T {
  try {
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function deriveNameFromEmail(email: string) {
  const prefix = email.split("@")[0] || "there";
  return prefix.length ? prefix[0].toUpperCase() + prefix.slice(1) : "there";
}

/* ----------------- Local Session Functions ----------------- */

/** Save or clear user in localStorage */
export function saveUser(user: HCUser | null) {
  try {
    if (!user) {
      localStorage.removeItem(SESSION_KEY);
      return;
    }
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  } catch {
    /* ignore */
  }
}

/** Read current signed-in user (used by Navbar / AuthGate) */
export function getUser(): HCUser | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as HCUser) : null;
  } catch {
    return null;
  }
}

/** Sign out both locally and from Supabase */
export async function signOut() {
  try {
    await supabase.auth.signOut(); // Supabase session
  } catch (err) {
    console.warn("Supabase sign-out failed:", err);
  } finally {
    localStorage.removeItem(SESSION_KEY);
  }
}

/* ----------------- Supabase Auth Listener ----------------- */

/**
 * Keeps localStorage in sync with Supabase auth state.
 * Call this once from ClientLayout (client side).
 */
export function initAuthListener(): () => void {
  const { data } = supabase.auth.onAuthStateChange(
    (event: string, session: any) => {
      try {
        const ev = String(event);

        // Handle login and user updates
        if (
          ev === "SIGNED_IN" ||
          ev === "USER_UPDATED" ||
          ev === "INITIAL_SESSION" ||
          ev === "TOKEN_REFRESHED"
        ) {
          const user = session?.user;
          if (user) {
            const name =
              (user.user_metadata && user.user_metadata.name) ||
              (user.user_metadata && user.user_metadata.full_name) ||
              deriveNameFromEmail(user.email ?? "");

            saveUser({
              id: user.id,
              email: user.email ?? "",
              name,
            });
          }
        }

        // Handle logout or account deletion
        if (ev === "SIGNED_OUT") {
          saveUser(null);
        }
      } catch (err) {
        console.error("Auth listener error:", err);
      }
    }
  );

  return () => {
    try {
      data?.subscription?.unsubscribe?.();
    } catch {
      // ignore unsubscribe errors
    }
  };
}

/* ----------------- Legacy Helpers (optional, for demo) ----------------- */

// These can stay if you want local demo login to still work without Supabase.
// They are no longer required for Supabase-based auth.

type StoredUser = {
  id: string;
  email: string;
  name?: string;
  hashedPassword: string;
  createdAt: string;
};

const USERS_KEY = "hc_users";

function uuid() {
  return crypto.getRandomValues(new Uint32Array(4)).join("-");
}

async function hashPassword(password: string) {
  const enc = new TextEncoder();
  const data = enc.encode(password);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function getUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    return safeParse<StoredUser[]>(raw, []);
  } catch {
    return [];
  }
}

function saveUsers(users: StoredUser[]) {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  } catch {}
}

export async function registerUser(opts: {
  email: string;
  password: string;
  name?: string;
}): Promise<
  | { ok: true; user: { id: string; email: string; name?: string } }
  | { ok: false; error: string }
> {
  const { email, password, name } = opts;
  if (!email || !password) return { ok: false, error: "Missing email or password" };

  const users = getUsers();
  const exists = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (exists) return { ok: false, error: "An account with this email already exists" };

  const hashedPassword = await hashPassword(password);
  const newUser: StoredUser = {
    id: uuid(),
    email,
    name: name || deriveNameFromEmail(email),
    hashedPassword,
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  saveUsers(users);

  return { ok: true, user: { id: newUser.id, email: newUser.email, name: newUser.name } };
}

export async function authenticateUser(email: string, password: string): Promise<HCUser | null> {
  if (!email || !password) return null;
  const users = getUsers();
  const found = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (!found) return null;

  const hashed = await hashPassword(password);
  if (hashed !== found.hashedPassword) return null;

  return { email: found.email, name: found.name };
}
