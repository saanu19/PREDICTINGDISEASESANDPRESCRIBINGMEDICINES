import React from 'react';

export default function Background() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Base gradient with white and teal */}
      <div className="absolute inset-0 bg-gradient-to-br from-white via-white to-white" 
           style={{ background: 'linear-gradient(135deg, #ffffff 0%, #f0f9f9 25%, #A8C5C5 100%)' }} />
      
      {/* Soft flowing shapes */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] rounded-full opacity-30"
           style={{ 
             background: 'radial-gradient(circle, #A8C5C5 0%, transparent 70%)',
             filter: 'blur(60px)'
           }} />
      
      <div className="absolute -bottom-32 -left-32 w-[500px] h-[500px] rounded-full opacity-20"
           style={{ 
             background: 'radial-gradient(circle, #A8C5C5 0%, transparent 70%)',
             filter: 'blur(80px)'
           }} />
      
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full opacity-15"
           style={{ 
             background: 'radial-gradient(circle, #A8C5C5 0%, transparent 70%)',
             filter: 'blur(100px)'
           }} />
      
      {/* Subtle overlay for depth */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/40 via-transparent to-transparent" />
    </div>
  );
}