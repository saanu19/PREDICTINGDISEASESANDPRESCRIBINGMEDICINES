// components/AuthGate.tsx
"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { getUser } from "@/lib/auth";

type Props = { children: React.ReactNode; fallback?: React.ReactNode };

export default function AuthGate({ children, fallback = null }: Props) {
  const [checked, setChecked] = useState(false);
  const [user, setUser] = useState<any | null>(null);
  const pathname = usePathname();

  useEffect(() => {
    // read localStorage
    const u = getUser();
    setUser(u);
    setChecked(true);
  }, [pathname]); // re-run when path changes

  useEffect(() => {
    // also listen to storage events (other tabs or programmatic updates)
    const onStorage = () => {
      setUser(getUser());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  // while checking, return null (no flash)
  if (!checked) return null;

  if (!user) return <>{fallback}</>;

  return <>{children}</>;
}
