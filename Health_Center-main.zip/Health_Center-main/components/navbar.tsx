"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { getUser, signOut } from "@/lib/auth";

const links = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
  { href: "/developer", label: "Developer" },
];

function initialsFromName(nameOrEmail: string | undefined) {
  if (!nameOrEmail) return "U";
  const parts = nameOrEmail.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 1).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

function displayName(name: string | undefined, email: string | undefined) {
  const raw = name || email || "User";
  // If it's an email, derive left side before @
  const label = raw.includes("@") ? raw.split("@")[0] : raw;
  // Capitalize words
  return label
    .split(/[\.\-_]/)
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
    .join(" ");
}

export function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<any | null>(null);
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    setUser(getUser());
  }, [pathname]);

  useEffect(() => {
    const onStorage = () => setUser(getUser());
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  useEffect(() => {
    const controlNavbar = () => {
      if (typeof window !== "undefined") {
        if (window.scrollY > lastScrollY && window.scrollY > 80) setIsVisible(false);
        else setIsVisible(true);
        setLastScrollY(window.scrollY);
      }
    };
    window.addEventListener("scroll", controlNavbar);
    return () => window.removeEventListener("scroll", controlNavbar);
  }, [lastScrollY]);

  if (!user) return null;

  const name = displayName(user.name, user.email);
  const initials = initialsFromName(user.name ?? user.email);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 w-full z-50 transition-all duration-300 ease-in-out",
        isVisible ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0"
      )}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div
          className="
            mt-2 flex items-center justify-between
            h-20 sm:h-24
            px-6 rounded-2xl
            border border-white/30
            shadow-lg
            backdrop-blur-md
            bg-white/40
          "
        >
          {/* Logo */}
<Link href="/" className="flex items-center group">
  <div className="flex-shrink-0 relative -ml-2 sm:-ml-6">
    <Image
      src="/logo.webp"
      alt="Health Center Logo"
      width={420}   // slightly larger intrinsic width
      height={420}
      className="h-20 sm:h-[6.5rem] md:h-[7rem] w-auto object-contain transition-transform duration-300 group-hover:scale-[1.03]"
    />
  </div>
  <span className="sr-only">Go to home</span>
</Link>

          {/* Nav Links */}
          <ul className="hidden md:flex items-center justify-center flex-1 space-x-2">
            {links.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  className={cn(
                    "px-5 py-2 text-sm font-medium rounded-full transition-all duration-300",
                    pathname === l.href
                      ? "text-white font-semibold bg-[#A8CDD2]"
                      : "text-slate-800 hover:text-blue-700 hover:bg-white/50"
                  )}
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>

          {/* Right: Avatar + Greeting + Logout */}
          <div className="flex items-center gap-4">
            {/* Avatar + name on md+ */}
            <div className="hidden md:flex items-center gap-3">
              {/* Avatar */}
              <div
                className="flex items-center gap-3 px-3 py-1 rounded-full bg-white/60 shadow-sm border border-white/40"
                aria-hidden
              >
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-slate-900 font-semibold text-sm shadow"
                  style={{ boxShadow: "0 6px 18px rgba(0,0,0,0.06)" }}
                >
                  {initials}
                </div>

                <div className="text-sm">
                  <div className="text-xs text-slate-600">Hi,</div>
                  <div className="text-sm font-semibold text-slate-800">{name}</div>
                </div>
              </div>
            </div>

            {/* Logout button (desktop) */}
            <div className="hidden md:block">
              <button
                onClick={() => {
                  signOut();
                  router.replace("/signin");
                }}
                className="inline-flex items-center gap-2 rounded-full bg-white/90 px-4 py-2 text-sm font-medium text-red-600 shadow hover:scale-[1.01] transition transform"
                title="Sign out"
              >
                <svg className="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden>
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7" />
                </svg>
                Logout
              </button>
            </div>

            {/* Mobile: avatar + small logout icon */}
            <div className="md:hidden flex items-center gap-2">
              <button
                onClick={() => {
                  signOut();
                  router.replace("/signin");
                }}
                className="h-10 w-10 rounded-full flex items-center justify-center bg-white/90 shadow text-red-600"
                aria-label="Logout"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden>
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Navbar;
