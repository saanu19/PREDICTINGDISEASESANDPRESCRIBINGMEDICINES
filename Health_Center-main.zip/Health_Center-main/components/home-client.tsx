"use client";

import { Suspense } from "react";
import SymptomForm from "@/components/symptom-form";
import Background from "@/components/background";

export default function HomeClient() {
  return (
    <main className="relative min-h-screen text-slate-900 overflow-hidden">
      {/* Background */}
      <Background />

      <div className="relative z-10 mx-auto max-w-5xl px-6 py-20">
        <Suspense>
          <SymptomForm />
        </Suspense>
      </div>
    </main>
  );
}
