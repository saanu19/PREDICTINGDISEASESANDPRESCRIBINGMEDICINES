"use client";

import React, { useEffect } from "react";
import { usePathname } from "next/navigation";
import Navbar from "@/components/navbar";
import Background from "@/components/background";
import AuthGate from "@/components/AuthGate";
import { initAuthListener } from "@/lib/auth"; // must exist and return an unsubscribe fn

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  // Treat these routes as "auth" pages where we want a full-screen background
  // and no navbar/footer/padding.
  const authPaths = ["/signin", "/signup", "/forgot-password", "/reset-password"];

  // Use startsWith so queries or trailing slashes don't break detection
  const isAuthPage = authPaths.some((p) => pathname?.startsWith(p));

  // Start the Supabase -> localStorage auth listener once on client mount.
  useEffect(() => {
    const unsubscribe = initAuthListener();
    return () => {
      try {
        unsubscribe();
      } catch {
        /* ignore */
      }
    };
  }, []);

  return (
    <>
      {/* Only render Background & Navbar on non-auth pages */}
      {!isAuthPage && (
        <AuthGate>
          <Background />
          <Navbar />
        </AuthGate>
      )}

      {/* Main content: add top padding only when navbar is visible */}
      <main className={`relative z-10 flex-grow ${!isAuthPage ? "pt-28 sm:pt-32" : "pt-0"}`}>
        {children}
      </main>

      {/* Footer only on non-auth pages */}
      {!isAuthPage && (
        <AuthGate>
          <footer className="border-t border-slate-300 bg-slate-100 relative z-10 shadow-inner">
            <div className="mx-auto max-w-7xl px-4 py-8 flex justify-center">
              <p className="text-sm text-slate-700 text-center">
                © 2025 <span className="font-semibold">Health Center</span>. For informational purposes
                only.
              </p>
            </div>
          </footer>
        </AuthGate>
      )}
    </>
  );
}
